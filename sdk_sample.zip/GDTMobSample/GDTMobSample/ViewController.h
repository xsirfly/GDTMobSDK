//
//  ViewController.h
//  GDTMobSample
//
//  Created by GaoChao on 13-10-31.
//  Copyright (c) 2013年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSArray *demoTitles;
    
    IBOutlet UITableView *_tableView;
}

@end
