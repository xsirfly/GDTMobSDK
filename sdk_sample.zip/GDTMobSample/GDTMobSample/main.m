//
//  main.m
//  GDTMobSample
//
//  Created by GaoChao on 13-12-9.
//  Copyright (c) 2013年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GDTMobAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GDTMobAppDelegate class]));
    }
}
