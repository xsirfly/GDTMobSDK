//
//  SplashViewContronller.h
//  GDTMobApp
//
//  Created by GaoChao on 15/8/21.
//  Copyright © 2015年 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GDTSplashAd.h"

@interface SplashViewController : UIViewController<GDTSplashAdDelegate>

@end
